#include "hash.h"
#include <iostream>
#include <fstream>
#include <list>
using namespace std;

void Hash::remove (string word)
{
	int key = hf(word);
	for(list<string>::iterator it=hashTable[key].begin(); it != hashTable[key].end();++it)
		if(*it == word)
			it = hashTable[key].erase(it);		

		double totalLength = 0;
		for(int i=0;i<HASH_TABLE_SIZE;i++)
			totalLength+=hashTable[i].size();
		double newAvgLength = totalLength/HASH_TABLE_SIZE;
		avgLength = (newAvgLength + avgLength) / 2.0;
}

void Hash::print ()
{
	for(int i=0;i<HASH_TABLE_SIZE;i++)
	{
		cout << i << ":\t";
		for(list<string>::iterator it=hashTable[i].begin(); it != hashTable[i].end();++it)
			cout << *it << ", ";
		cout << endl;
	}
}

void Hash::processFile (string filename)
{
	int key;
	ifstream fp(filename.c_str());
	if (!fp.is_open()) {
		cout << "can't open file " << endl;
	}
	string word;
	while (getline(fp, word)) {
		key = hf(word); 
		if(!hashTable[key].empty())
			collisions++;

		hashTable[key].push_back(word);
		int x = hashTable[key].size();
		if(x > longestList)
			longestList = x;

		double totalLength = 0;
		for(int i=0;i<HASH_TABLE_SIZE;i++)
			totalLength+=hashTable[i].size();
		double newAvgLength = totalLength/HASH_TABLE_SIZE;
		avgLength = (newAvgLength + avgLength) / 2.0;

	}
	fp.close();
}

bool Hash::search (string word)
{
	int key = hf(word);
	for(list<string>::iterator it=hashTable[key].begin(); it != hashTable[key].end();++it)
		if(*it == word)
			return true;		
	return false;
}
void Hash::output (string filename)
{
	ofstream outputFile(filename.c_str());
	for(int i=0;i<HASH_TABLE_SIZE;i++)
	{
		outputFile << i << ":\t";
		for(list<string>::iterator it=hashTable[i].begin(); it != hashTable[i].end();++it)
			outputFile << *it;
		outputFile << endl;
	}
	outputFile.close();
}
void Hash::printStats ()
{
	cout << "Total collisions = " << collisions << endl;
	cout << "Longest list = " << longestList << endl;
	cout << "Average list length = " << avgLength << endl; 
}