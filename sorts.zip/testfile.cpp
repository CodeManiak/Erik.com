#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <iostream>
using namespace std;

class Record {                         // declaration of a Record
   public:
      std::string* city;
      std::string* state;
      int population;

      Record(std::string& c, std::string& s, int p) {
      city = new std::string(c);
      state = new std::string(s);
      population = p;
      }

      ~Record() {
         delete city;
         delete state;
      }
};

void insertionSort(int myArray[], int length);
void merge(int p, int q, int r, int type);
void mergeSort(int p, int r, int type);
void print(int myArray[], int length);
std::vector<Record*> data;  
void printVector(vector<Record*> myVector); 

int main()
{
   Record* record;
   string city = "Chico";
   string state = "CA";
   int population = 80000;
   record = new Record(city, state, population);
   data.push_back(record);
   Record* record2;
   string city2 = "Sacramento";
   string state2 = "CA";
   int population2 = 500000;
   record2 = new Record(city2, state2, population2);
   data.push_back(record2);
   Record* record3;
   string city3 = "Reno";
   string state3 = "NV";
   int population3 = 300000;
   record3 = new Record(city3, state3, population3);
   data.push_back(record3);
   int array1 [3] = {1,5,3};
   int array2 [10] = {1,5,3,7,8,2,3,6,3,5};
   int array3 [5] = {1,5,3,10,5};
   printVector(data);
   mergeSort(0,data.size()-1,2);
   printVector(data);
    {
        std::vector<Record*>::iterator it = data.begin();
           while (it != data.end()) {
              delete *it;
              it++;
            }
    }
}

void insertionSort(int myArray[], int length)
{
    int key;
    int i;
    for(int j = 1; j < length; j++)
    {
        key =  myArray[j];
        i = j-1;
        while(i > 0 && myArray[i] > key)
        {
            myArray[i+1] = myArray[i];
            i = i-1;
        }
        myArray[i+1] = key;
    }
} 
void mergeSort(int p, int r, int type)
{
    int q;
    cout<<"MERGESORT: "<<endl<<endl<<"P: "<<p<<endl<<"R: "<<r<<endl;
    if(p < r)
    {
        q = (p+r)/2;
        mergeSort(p,q,type);
        mergeSort(q+1,r,type);
        merge(p,q,r,type);
    }      
}
void merge(int p, int q, int r, int type)
{
    cout<<"MERGE: "<<endl<<endl<<"P: "<<p<<endl<<"Q: "<<q<<endl<<"R: "<<r<<endl;
    int n1 = q-p +1;
    int n2 = r-q;
    std::vector<Record*> left;
    std::vector<Record*> right;
    int i = 0;
    int j = 0;
    for(i = 0;i<n1;i++)
        left.push_back(data[p+i]);
    for(j = 0; j<n2; j++)
        right.push_back(data[q+j+1]);
    i=0;
    j=0;
    for(int k=p; k<=r; k++)
    {
        if(!type)
        {
            if(left[i]->population <= right[j]->population)
            {
                data[k]=left[i];
                i=i+1;
            }
            else
            {
                data[k]=right[j];
                j=j+1;
            }
        }
        else 
        {
            if(*left[i]->city <= *right[j]->city)
            {
                data[k]=left[i];
                i=i+1;
            }
            else
            {
                data[k]=right[j];
                j=j+1;
            }
        }
        
    }
}
void print(int myArray[], int length)
{
    for(int i = 0; i < length-1; i++)
    {
        cout << myArray[i] << ", ";
    }
}
void printVector(vector<Record*> myVector)
{
    for(int i = 0; i < myVector.size(); i++)
    {
        cout << myVector[i]->population << ", ";
    }
}
