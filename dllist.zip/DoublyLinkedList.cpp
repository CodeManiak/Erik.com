/**
 * @file DoublyLinkedList.cpp   Implementation of a DoublyLinkedList for music.
 * 
 * @brief
 *    Implementation of DoublyLinkedList for music, where a Node is
 *    used to store the list pointers.
 *
 * @author Erik Mellum
 * @date 9/2/2013
*/
#include "DoublyLinkedList.h"
using namespace std;
/**
* Default Constructor 
* Initializes head and tail to null
**/
DoublyLinkedList::DoublyLinkedList()
{
    head = NULL;
    tail = NULL;
    current = NULL;
}
/**
* Doubly Linked List Destructor
* Deletes the memory allocated for each node until the list is empty.
**/
DoublyLinkedList::~DoublyLinkedList()
{  
    Node* i = head;
    Node* j;
    if(!empty())
    {
        while(i != NULL)
        {
            j = i;
            // handles the removal of the final node 
            if(i->next == NULL)
            {
                delete i;
                i = NULL;
            }
            // handles a list size of greater than one
            else
            {   
                i = i->next;
                delete j;
                j = NULL;
            }
        }  
    }    
}
/**
* Specifies whether or not the list is empty
* @return a bool that is true if the list is empty and false otherwise.
**/
bool DoublyLinkedList::empty()
{
    if(head == NULL)
        return true;
    return false;
}
/**
* append is used to add songs to the end of the playlist.
* @param string& s the new data to put inside the list.
* Appends a song to the end of the playlist and makes it the current song
**/
void DoublyLinkedList::append(string& s)
{
    string* newSong = new string(s);
    if(empty())
    {
        current = tail = head = new Node();
        current->data = newSong;
    }
    else
    {
        current = tail;
        insertAfter(s);
    }
        
}
/**
* insertBefore is used to insert songs before the current song on the list.
* @param string& s the new data to put inside the list.
**/
void DoublyLinkedList::insertBefore(string& s)
{
    if(!empty())
    {
        string* newSong = new string(s);
        Node* newNode = new Node();
        newNode->data = newSong; 
        
        newNode->next = current;
        newNode->prev = current->prev;
        if(current->prev == NULL)
            head = newNode;
        else
            current->prev->next = newNode;
    current->prev = newNode;
        current = newNode;
    }
    else
        append(s);
}
/**
* insertAfter is used to insert songs after the current song on the list.
* @param string& s the new data to put inside the list.
**/
void DoublyLinkedList::insertAfter(string& s)
{
    if(!empty())
    {  
        string* newSong = new string(s);
        Node* newNode = new Node();
        newNode->data = newSong; 
        
        newNode->prev = current;
        newNode->next = current->next;
        if(current->next == NULL)
            tail = newNode;
        else
            current->next->prev = newNode;
    current->next = newNode;
        current = newNode;
        
    }
    else
        append(s);
}
/**
* remove is used to take songs off of the playlist.
* @param string& s the song to remove.
**/
void DoublyLinkedList::remove(string& s)
{
    if(!empty())
    {
        Node* i = head;
        Node* j;
        // Removal of a node with a list size of 1
        if(i->next == NULL)
        {
            if(*(i->data) == s)
            {
        
                delete i;
                current = head = tail = NULL;
            }
        }
        else
        {   
            // iterates until i contains the string to remove. j trails behind.
            while(*(i->data) != s)
            {   
                if(i->next != NULL)
                {
                    j=i;
                    i=i->next;
                }
                else
                    break;
            }
            if(*(i->data) == s)
            {
                // Tests to see if the node being deleted is the tail
                if(i->next == NULL)
                {
                    j->next = NULL;
                    current = tail = j;
                    delete i;
                }
                // Tests to see if the node being deleted is the head
                else if(i->prev == NULL)
                {
                    head=i->next;
                    head->prev = NULL;
                    current = head;
                    delete i;                
                }
                // Removes nodes with connections on either side
                else 
                { 
                    current = i->next;
                    j->next=i->next;
                    i->next->prev = j;
                    delete i;
                }
            }
        }
    }  
}
/**
* begin is used to set the current node equal to the first node
**/
void DoublyLinkedList::begin()
{
    current = head;
}
/**
* end is used to set the current node equal to the last node
**/
void DoublyLinkedList::end()
{
    current = tail;
}
/**
* next sets the current node equal to the currents nodes next node
* @return bool a bool that is true when the next node is not null
**/
bool DoublyLinkedList::next()
{
    
    if(current->next == NULL)
        return false;
    current = current->next;
    return true;
}
/**
* prev sets the current node equal to the currents nodes previous node
* @return bool a bool that is true when the prev node is not null
**/
bool DoublyLinkedList::prev()
{
    
    if(current->prev == NULL)
        return false;
    current = current->prev;
    return true;
}
/**
* find is used to locate a song in the playlist
* @param string& s the song to be located in the playlist
* @return bool a bool that is true if the data is located in a node
**/
bool DoublyLinkedList::find(string& s)
{
    if(empty())
        return false;
    else
    {
        Node* tempNode = head;
        do{
        
            if(*(tempNode->data) == s)
            {
        
                current = tempNode;
                return true;
            }
            tempNode = tempNode->next;
        
        } while(tempNode != NULL);
    
        return false;
    }
}
/**
* getData is used to return the data of the current song
* @return string& a string pointer that contains the data
**/
const string& DoublyLinkedList::getData()
{
    return *(current->data);
}
