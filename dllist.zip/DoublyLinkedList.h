/**
 * @file DoubleLinkedList.h   Declaration of a DoublyLinkedListed for music.
 * 
 * @brief
 *    Implementation of DoublyLinkedList for music, where a Node is
 *    used to store the list pointers.
 *
 * @author Erik Mellum
 * @date 9/2/2013
*/

#pragma once
#include <string>
using namespace std;

class DoublyLinkedList
{
    public:

        DoublyLinkedList();
        ~DoublyLinkedList();
        bool empty();
        void append(string& s);
        void insertBefore(string& s);
        void insertAfter(string& s);
        void remove(string& s);
        void begin();
        void end();
        bool next();
        bool prev();
        bool find(string& s);
        const string& getData();
    private:
    /**
    * Node is a class used to hold the pointers for the next, and previous
    * nodes, as well as a string* pointer data used to hold the data. Memory
    * is dynamically allocated in the constructor and cleaned up by the
    * destructor. For use with the DoublyLinkedList class.
    **/
        class Node
        {
            public:
                Node* next;
                Node* prev;
                string* data;
                Node(){next = NULL; prev = NULL; data = NULL;};
                ~Node(){delete data; data = NULL;};
        };
        Node* head;
        Node* tail;
        Node* current;
};
